package Services;


import static Repository.Info.*;
import static Repository.routine.addToList;
import static Repository.routine.schedule;

public class services {

    public static void createRoutine(int day, int hr, int sub) {

        System.out.println("1. English Grammar\n2. Mathematics\n3. Physics\n4. Chemistry\n5. Biology");
        schedule.add(addToList(day, hr, sub));

    }

    public static void showRoutine() {
        for (Model.routineClass routineClass : schedule) {
            System.out.println(routineClass.day + " " + routineClass.hr + " " + subjectLinkedList.get(routineClass.sub).sub_name);
        }
    }

    public static void listCourses() {

        for (int i = 0; i < subjectLinkedList.size(); i++) {
            System.out.println(subjectLinkedList.get(i).sub_name + ", " + teacherLinkedList.get(i).t_name);
        }

    }


}
