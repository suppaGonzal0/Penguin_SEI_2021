package App;

import static Services.services.*;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("A. Create Routine\nB. Show Routine\nC. List Courses with Teachers Name");


        while (sc.hasNext()) {
            String inp = sc.next().toUpperCase();

            switch (inp) {
                case "A" -> createRoutine(sc.nextInt(), sc.nextInt(), sc.nextInt());
                case "B" -> showRoutine();
                case "C" -> listCourses();
                default -> System.out.println("Invalid input");
            }

            System.out.println("\nA. Create Routine\nB. Show Routine\nC. List Courses with Teachers Name");
        }
    }
}
