package Model;

public class routineClass {

    public int day, hr, sub;

    public routineClass(int a, int b, int c) {
        day = a;
        hr = b;
        sub = c;
    }

}
