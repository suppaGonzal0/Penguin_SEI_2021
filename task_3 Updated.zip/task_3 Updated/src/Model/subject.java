package Model;

public class subject {

    public String sub_name;

    public subject(String s) {
        sub_name = s;
    }

}
