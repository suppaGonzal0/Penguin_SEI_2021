package Model;

public class teacher {

    public String t_name;

    public teacher(String t) {
        t_name = t;
    }

}
