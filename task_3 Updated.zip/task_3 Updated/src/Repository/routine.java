package Repository;

import Model.*;

import java.util.LinkedList;

public class routine {

    public static routineClass addToList(int day, int hr, int sub){
        return new routineClass(day, hr, sub);
    }

    public static LinkedList<routineClass> schedule = new LinkedList<>();

}
