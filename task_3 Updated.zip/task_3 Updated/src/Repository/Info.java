package Repository;

import Model.*;

import java.util.LinkedList;

public class Info {

    public static LinkedList<subject> subjectLinkedList = new LinkedList<>() {{
        add(new subject("English Grammar"));
        add(new subject("Mathematics"));
        add(new subject("Physics"));
        add(new subject("Chemistry"));
        add(new subject("Biology"));
    }};

    public static LinkedList<teacher> teacherLinkedList = new LinkedList<>() {{
        add(new teacher("John Smith"));
        add(new teacher("Lara Gilbert"));
        add(new teacher("Johanna Kabir"));
        add(new teacher("Danniel Robertson"));
        add(new teacher("Larry Cooper"));
    }};

}